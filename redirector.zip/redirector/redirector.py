#!/usr/bin/env python3
import subprocess
import json
import time
import os

# -------------------------------------------------------------
# 1) Definições de portas das instâncias
# -------------------------------------------------------------
# Cowrie1 (entrada)
C1_SSH_PORT   = 2222
C1_TELNET_PORT= 2223

# Cowrie2 (destino do redirecionamento)
C2_SSH_PORT   = 2224
C2_TELNET_PORT= 2225

# -------------------------------------------------------------
# 2) Caminho absoluto para o JSON de logs do cowrie1
# -------------------------------------------------------------
# Ajuste este caminho se sua estrutura for diferente.
LOGFILE = os.path.expanduser(
    "~/meu-cowrie/cowrie1/var/log/cowrie/cowrie.json"
)

# -------------------------------------------------------------
# 3) Conjunto para controlar quais IPs já foram redirecionados
# -------------------------------------------------------------
redirected_ips = set()

# -------------------------------------------------------------
def apply_iptables_redirect(src_ip):
    """
    Aplica duas regras de iptables para redirecionar todo tráfego:
      - TCP de src_ip:2222 --> 127.0.0.1:2224
      - TCP de src_ip:2223 --> 127.0.0.1:2225
    """
    # Regra para SSH
    cmd_ssh = [
        "sudo", "iptables", "-t", "nat", "-A", "PREROUTING",
        "-p", "tcp", "-s", src_ip,
        "--dport", str(C1_SSH_PORT),
        "-j", "REDIRECT", "--to-ports", str(C2_SSH_PORT)
    ]
    # Regra para Telnet
    cmd_telnet = [
        "sudo", "iptables", "-t", "nat", "-A", "PREROUTING",
        "-p", "tcp", "-s", src_ip,
        "--dport", str(C1_TELNET_PORT),
        "-j", "REDIRECT", "--to-ports", str(C2_TELNET_PORT)
    ]

    print(f"[redirector] Redirecionando {src_ip}:"
          f"{C1_SSH_PORT}→{C2_SSH_PORT} e {C1_TELNET_PORT}→{C2_TELNET_PORT}")
    subprocess.run(cmd_ssh, check=True)
    subprocess.run(cmd_telnet, check=True)

# -------------------------------------------------------------
def tail_json_and_redirect():
    """
    Abre o arquivo LOGFILE em modo “tail -F” e, a cada linha JSON válida,
    verifica se é um evento de login bem-sucedido. Se for, extrai o IP
    e, caso não tenha sido redirecionado antes, aplica iptables.
    """
    # Garante que o arquivo exista (evita erro inicial)
    if not os.path.isfile(LOGFILE):
        print(f"Arquivo de log não encontrado: {LOGFILE}")
        return

    # Executa 'tail -n0 -F LOGFILE' para ler novas linhas continuamente
    with subprocess.Popen(
        ["tail", "-n0", "-F", LOGFILE],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    ) as proc:
        while True:
            line = proc.stdout.readline()
            if not line:
                time.sleep(0.1)
                continue

            line = line.strip()
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue  # pula linhas não-JSON

            # Critério de redirecionamento: login bem-sucedido
            if event.get("eventid") == "cowrie.login.success":
                # Tenta extrair o IP do campo "src_addr"
                src_ip = event.get("src_addr")
                if not src_ip:
                    # Se não existir "src_addr", pega do "system"
                    # Exemplo de system: "SSHService ssh-connection,1,192.168.0.10"
                    system = event.get("system", "")
                    parts = system.split(",")
                    if len(parts) >= 3:
                        src_ip = parts[-1]

                # Se achou um IP e ainda não redirecionamos
                if src_ip and src_ip not in redirected_ips:
                    try:
                        apply_iptables_redirect(src_ip)
                        redirected_ips.add(src_ip)
                    except subprocess.CalledProcessError as e:
                        print(f"[redirector] Erro ao aplicar iptables: {e}")

# -------------------------------------------------------------
if __name__ == "__main__":
    print("[redirector] Iniciando listener em", LOGFILE)
    tail_json_and_redirect()
